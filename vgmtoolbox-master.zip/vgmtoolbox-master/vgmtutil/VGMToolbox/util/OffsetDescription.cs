﻿namespace VGMToolbox.util
{
    public class OffsetDescription
    {
        public string OffsetValue { set; get; }
        public string OffsetSize { set; get; }
        public string OffsetByteOrder { set; get; }
    }
}
