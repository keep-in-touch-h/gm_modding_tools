﻿namespace VGMToolbox.util
{
    public interface IDeepCopy<T>
    {
        T DeepCopy();
    }
}
