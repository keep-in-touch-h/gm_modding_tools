﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VGMToolbox.format
{
    public class Wsr
    {
    }
}
