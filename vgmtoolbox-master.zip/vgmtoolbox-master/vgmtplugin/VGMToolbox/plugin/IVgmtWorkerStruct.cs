﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VGMToolbox.plugin
{    
    public interface IVgmtWorkerStruct
    {
        string[] SourcePaths { get; set; }
    }
}
